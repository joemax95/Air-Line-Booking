-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.20-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for airline_booking
CREATE DATABASE IF NOT EXISTS `airline_booking` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `airline_booking`;

-- Dumping structure for table airline_booking.air_bus
CREATE TABLE IF NOT EXISTS `air_bus` (
  `id_airBus` int(10) NOT NULL AUTO_INCREMENT,
  `airBus_no` varchar(50) NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_airBus`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table airline_booking.air_bus: ~0 rows (approximately)
/*!40000 ALTER TABLE `air_bus` DISABLE KEYS */;
INSERT INTO `air_bus` (`id_airBus`, `airBus_no`, `capacity`) VALUES
	(1, '46', 348),
	(2, '48', 234);
/*!40000 ALTER TABLE `air_bus` ENABLE KEYS */;

-- Dumping structure for table airline_booking.flight
CREATE TABLE IF NOT EXISTS `flight` (
  `id_flight` int(10) NOT NULL AUTO_INCREMENT,
  `airbus_no` varchar(50) DEFAULT NULL,
  `flight_no` varchar(50) DEFAULT NULL,
  `depart_from` varchar(50) DEFAULT NULL,
  `arrival_to` varchar(50) DEFAULT NULL,
  `departure_date` date DEFAULT NULL,
  `departure_time` time DEFAULT NULL,
  `arrival_time` time DEFAULT NULL,
  `first_class` float DEFAULT NULL,
  `business` float DEFAULT NULL,
  `economy` float DEFAULT NULL,
  PRIMARY KEY (`id_flight`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table airline_booking.flight: ~0 rows (approximately)
/*!40000 ALTER TABLE `flight` DISABLE KEYS */;
INSERT INTO `flight` (`id_flight`, `airbus_no`, `flight_no`, `depart_from`, `arrival_to`, `departure_date`, `departure_time`, `arrival_time`, `first_class`, `business`, `economy`) VALUES
	(1, '46', '85', 'Port-au-Prince', 'Venezuela', '2021-09-17', '05:50:00', '06:50:00', 456, 345, 123);
/*!40000 ALTER TABLE `flight` ENABLE KEYS */;

-- Dumping structure for table airline_booking.passenger
CREATE TABLE IF NOT EXISTS `passenger` (
  `id_passenger` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `passport` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_passenger`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table airline_booking.passenger: ~0 rows (approximately)
/*!40000 ALTER TABLE `passenger` DISABLE KEYS */;
/*!40000 ALTER TABLE `passenger` ENABLE KEYS */;

-- Dumping structure for table airline_booking.user
CREATE TABLE IF NOT EXISTS `user` (
  `id_user` int(10) NOT NULL AUTO_INCREMENT,
  `email_user` varchar(50) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL DEFAULT '0',
  `password_user` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table airline_booking.user: ~0 rows (approximately)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id_user`, `email_user`, `username`, `password_user`) VALUES
	(1, 'jean@gmail.com', 'jean', '8cb2237d0679ca88db6464eac60da96345513964'),
	(2, 'madison@gmail.com', 'admin', '8cb2237d0679ca88db6464eac60da96345513964'),
	(3, 'daniel@gmail.com', 'danio', '8cb2237d0679ca88db6464eac60da96345513964');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;

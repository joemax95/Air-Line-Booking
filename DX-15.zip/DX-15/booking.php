
<?php
  
  include "admin/db_connect.php";

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title></title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="form-validation.css">
</head>
<body>
  <nav class="navbar navbar-light bg-light">
    <div class="container">
      <a class="navbar-brand" href="#">DX-FLIGHT</a>
    </div>
  </nav>

  <br>

<div class="container">
    <main>
      <div class="row g-5">
        <div class="col-md-7 col-lg-8">
          <h4 class="mb-3">Passenger Information</h4>
          <hr class="my-4">

          <form class="needs-validation" novalidate action="bookingProcess.php" method="post">
            <div class="row gy-3">
              <div class="col-md-6">
                <label for="Firstname" class="form-label">First name</label>
                <input type="text" class="form-control" placeholder="" required name = "firstname" >
                <div class="invalid-feedback">
                  Please enter your firstname
                </div>
              </div>

              <div class="col-md-6">
                <label for="Lastname" class="form-label">Last name</label>
                <input type="text" class="form-control" placeholder="" required name="lastname">
                <div class="invalid-feedback">
                  Please enter your lastname
                </div>
              </div>

              <div class="col-md-5">
                <label for="Email" class="form-label">Email</label>
                <input type="email" class="form-control" placeholder="" required name="email">
                <div class="invalid-feedback">
                  Please enter your email
                </div>
              </div>

              <div class="col-md-5">
                <label for="Phone" class="form-label" >Phone</label>
                <input type="phone" class="form-control" placeholder="" name="phone" required> 
                <div class="invalid-feedback">
                  Please enter your phone number
                </div>
              </div>

              <div class="col-md-6">
                <label for="BirthDate" class="form-label">Birth date</label>
                <input type="date" name="birth_date" class="form-control" required min="1950-01-01" max="2001-12-31">
                <div class="invalid-feedback">
                  Please enter your birth date
                </div>
              </div>

              <div class="col-md-6">
                <label for="adult" class="form-label">Passport</label>
                <select class="form-select" id="state" required name="passport">
                  <option value="">Choose...</option>
                  <option>USA</option>
                  <option>Canada</option>
                  <option>Brasil</option>
                  <option>Venezuela</option>
                  <option>Cuba</option>
                  <option>Chili</option>
                  <option>Argentina</option>
                  <option>Dominicana</option>
                  <option>Colombia</option>
                  <option>Haiti</option>
                </select>
                <div class="invalid-feedback">
                  Please enter your passport number
                </div>
              </div>

            </div>

            <hr class="my-4">

            <button class="w-100 btn btn-primary btn-lg" type="submit" name="passenger">Continue</button>
          </form>
        </div>
      </div>
    </main>

    <footer class="my-5 pt-5 text-muted text-center text-small">
      <p class="mb-1">&copy; 2021</p>
      <ul class="list-inline">
        <li class="list-inline-item"><a href="#">Privacy</a></li>
        <li class="list-inline-item"><a href="#">Terms</a></li>
        <li class="list-inline-item"><a href="#">Support</a></li>
      </ul>
    </footer>
  </div>
  <script type="text/javascript" src="form-validation.js"></script>  
</body>
</html>
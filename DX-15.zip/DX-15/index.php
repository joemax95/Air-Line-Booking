
<?php
  
  include "admin/db_connect.php";

  $date = new DateTime();

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="form-validation.css">
</head>
<body>
	<nav class="navbar navbar-light bg-light">
	  <div class="container">
	    <a class="navbar-brand" href="#">DX-FLIGHT</a>
	  </div>
	</nav>

	<br>

<div class="container">
    <main>
      <div class="row g-5">
        <div class="col-md-7 col-lg-8">
          <h4 class="mb-3">Book your flight</h4>
          <hr class="my-4">

          <form class="needs-validation" novalidate action="bookingProcess.php" method="post">

            <div class="row gy-3">
              <div class="col-md-3">
                <label for="class" class="form-label">Class</label>
                <select class="form-control" name="class">
                  <option>Economic</option>
                  <option>Business</option>
                  <option>First</option>
                </select>
              </div>
            </div>

            <br>

            <div class="row">
              <div class="col-auto">
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" onclick="showContent()" value="round-trip">
                  <label class="form-check-label" for="flexRadioDefault1">
                        Round-Trip
                  </label>
                </div>
              </div>

              <div class="col-auto">
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" onclick="hideContent()" value="one-way" checked>
                  <label class="form-check-label" for="flexRadioDefault2">
                        One-Way
                  </label>
                </div>
              </div>
            </div>

            <br>

            <div class="row gy-3">
              <div class="col-md-6">
                <label for="exampleDataList" class="form-label">From</label>
                <input type="text" class="form-control" list="datalistOptions" placeholder="" required name = "from" >
                <datalist id="datalistOptions">
                  <option value="Port-au-Prince">
                </datalist>
                <div class="invalid-feedback">
                  Departure from is required
                </div>
              </div>

              <div class="col-md-6">
                <label for="exampleDataList" class="form-label">To</label>
                <input type="text" class="form-control"  list="datalistOptions1" placeholder="" required name="to">
                <datalist id="datalistOptions1">
                  <?php

                  $r = $db_connect->query("SELECT arrival_to FROM flight");

                  while($row = $r->fetch()){

                  ?>
                  <option value="<?php echo $row['arrival_to']; ?>">
                <?php
                }
                ?>
                </datalist>
                <div class="invalid-feedback">
                  Arrival destination is required
                </div>
              </div>

              <div class="col-md-5">
                <label for="DepartDate" class="form-label">Departure date</label>
                <input type="date" class="form-control" id="dateDptr" placeholder="" required min="<?php echo $date->format('Y-m-d'); ?>" name="departDate">
                <div class="invalid-feedback">
                  Departure date is required
                </div>
              </div>

              <div class="col-md-5">
                <label for="returnDate" class="form-label" >Return date</label>
                <input type="date" class="form-control" id="add" placeholder="" style="visibility: hidden;" name="returnDate">
              </div>

              <div class="col-md-6">
                <label for="adult" class="form-label">Adult</label>
                <select class="form-control" name="adult">
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                  <option>6</option>
                  <option>7</option>
                  <option>8</option>
                  <option>9</option>
                  <option>10</option>
                </select>
              </div>

              <div class="col-md-6">
                <label for="adult" class="form-label">Children</label>
                <select class="form-control" name="children">
                  <option>0</option>
                  <option>1</option>
                  <option>2</option>
                  <option>3</option>
                  <option>4</option>
                  <option>5</option>
                  <option>6</option>
                  <option>7</option>
                  <option>8</option>
                  <option>9</option>
                  <option>10</option>
                </select>
              </div>

            </div>

            <hr class="my-4">

            <button class="w-100 btn btn-primary btn-lg" type="submit" name="booking">Search</button>
          </form>
        </div>
      </div>
    </main>

    <footer class="my-5 pt-5 text-muted text-center text-small">
      <p class="mb-1">&copy; 2021</p>
      <ul class="list-inline">
        <li class="list-inline-item"><a href="#">Privacy</a></li>
        <li class="list-inline-item"><a href="#">Terms</a></li>
        <li class="list-inline-item"><a href="#">Support</a></li>
      </ul>
    </footer>
  </div>
  <script type="text/javascript" src="form-validation.js"></script>
  <script type="text/javascript">
    let departDateInput;
    document.getElementById('dateDptr').addEventListener("change", function(){
      let input = this.value;
      //let dateEntered = new Date(input);
      departDateInput = input;
      let element = document.getElementById("add");
        element.min=departDateInput;
    });

    let element = document.getElementById("add");

    function hideContent() {
      element.style.visibility = "hidden";
    }

    function showContent(){
      element.style.visibility= "visible";
    }
  </script>
	
</body>
</html>

<?php

    session_start();

    include "admin/db_connect.php";

    echo $_SESSION['to'];

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body>
    <nav class="navbar navbar-light bg-light">
      <div class="container">
        <a class="navbar-brand" href="booking.php">DX-Flight</a>
      </div>
    </nav>

    <br>

    <div class="container">
        <h3>Choose your Flight</h3>
        <br>
        <div class="list-group">
        <?php

            $from = $_SESSION['from'];
            $arrival = $_SESSION['to'];

            $r = $db_connect->query("SELECT id_flight, depart_from, arrival_to, departure_date, departure_time, arrival_time, economy FROM  flight WHERE depart_from = '$from' AND arrival_to = '$arrival'");

            while ($row = $r->fetch()) {
                      
        ?>
          <a href="bookingProcess.php?setBooking=<?php echo $row['id_flight']; ?>" class="list-group-item list-group-item-action" aria-current="true">
            <div class="d-flex w-100 justify-content-between">
              <h5 class="mb-1"><?php echo $row['depart_from']; ?> to <?php echo $row['arrival_to']; ?></h5>
              <small><?php echo $row['departure_date'];?></small>
            </div>
            <div class="d-flex w-100 justify-content-between">
              <p class="mb-1"><?php echo $row['departure_time']." - ".$row['arrival_time']; ?></p>
              <h4>$<?php echo $row['economy']; ?></h4>
            </div>
            
            <small><?php echo $_SESSION['class']; ?></small>
          </a>
          <br>
    <?php
        } 
    ?>       
        </div>
    </div>
    
</body>
</html>

<?php

  include "db_connect.php";

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Flight List</title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../sidebars/sidebars.css">
</head>
<body>
	<!-- <nav class="navbar navbar-light bg-light">
	  <div class="container">
	    <a class="navbar-brand" href="#">Navbar</a>
	  </div>
	</nav>

	<br> -->

  
  <div class="container-fluid">
    <main>
      <!-- Sidebar -->
      <?php include 'sidebars.php';?>
      <!-- End Sidebar -->
      <div class="b-example-divider"></div>

      <div class="container" style="margin-left: 20px;">
        <br>
        <h3>Welcome Admin</h3>
        <hr class="my-3">
      </div>

    </main>    
  </div>
  


<script type="text/javascript" src="../sidebars/sidebars.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>	
</body>
</html>
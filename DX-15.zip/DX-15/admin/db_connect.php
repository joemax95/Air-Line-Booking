<?php

	try {
        $db_connect = new PDO('mysql:host=localhost;dbname=airline_booking', 'root', '');
    } catch (Exception $e) {
        die('Impossible de connecter avec la base'.$e->getMessage());
    }
?>
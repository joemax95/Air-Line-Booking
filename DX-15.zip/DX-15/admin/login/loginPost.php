<?php
	
	require "../db_connect.php";
	session_start();
	#$db = new PDO('mysql:host=localhost;dbname=airline_reservation', 'root', '');

	if (isset($_POST['login'])) {

	    $r = $db_connect->query("SELECT username, password_user FROM user");

	    $row = $r->fetch();

		if ($_POST['username'] == $row['username']) {
			$_SESSION['username'] = $row['username'];
			$_SESSION['password'] = $row['password_user'];
			
			header('location:../index.php');
		}else{
			echo "Li pa bon!!!";
		}
	}

?>

<?php
  
  session_start();

  if(isset($_SESSION['id_user']))
    $id_user = $_SESSION['id_user'];

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../sidebars/sidebars.css">
</head>
<body>
	<!-- <nav class="navbar navbar-light bg-light">
	  <div class="container">
	    <a class="navbar-brand" href="#">Navbar</a>
	  </div>
	</nav>

	<br> -->

  
  <div class="container-fluid">
    <main>
      <!-- Sidebar -->
      <?php include 'sidebars.php';?>
      <!-- End Sidebar -->
      <div class="b-example-divider"></div>

      <div class="container" style="margin-left: 20px;">
        <br>
        <h3>New Account</h3>
        <hr class="my-3">

        <br>
        <form action="process.php?<?php if(isset($_SESSION['id_user'])) echo "idUser=".$_SESSION['id_user']; ?>" method="post">
          <div class="row">
            <div class="col-md-6">
              <label for="Email" class="form-label">Email</label>
              <input type="email" min="0" name="email" class="form-control" required value="<?php if(isset($_SESSION['email_user'])) echo $_SESSION['email_user']; ?>">
            </div>
          </div>

          <div class="row">
            <div class="col-md-6">
              <label for="Username" class="form-label">Usernam</label>
              <input type="text" name="username" min="0" class="form-control" value="<?php if(isset($_SESSION['username'])) echo($_SESSION['username']); ?>">
            </div>
          </div>

          <div class="row">
            <div class="col-md-6">
              <label for="Username" class="form-label">Password</label>
              <input type="password" name="password" min="0" class="form-control">
            </div>
          </div>
          
          <br>

          <hr>

          <?php
          if (isset($_SESSION['email_user'])) {
          ?>
          <button type="submit" class="btn btn-primary w-50 d-flex justify-content-center" name="updateUser">Save Change</button>
          <?php
          }else{
          ?>
          <button type="submit" class="btn btn-primary w-50 d-flex justify-content-center" name="addUser">Create</button>
          <?php
          }
          ?> 
        </form>
        

      </div>

    </main>    
  </div>
  


<script type="text/javascript" src="../sidebars/sidebars.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>	
</body>
</html>

<?php
  unset($_SESSION['id_user']);
  unset($_SESSION['email_user']);
  unset($_SESSION['username']);

?>
<?php

	include 'db_connect.php';

	/*En programmation une fonction prend en compte uniquement les variables declare localement.
	Donc pour utiliser une variable hors de la fonction, il faut declarer cette variable
	de maniere global.  */ 

	#Declaration d'une variable global.	
	$GLOBALS['dbConnect'] = $db_connect; 

	function addFlight(array $flight){

		$db = $GLOBALS['dbConnect'];
		
		$r = $db->prepare("INSERT INTO flight(airbus_no, flight_no, depart_from, arrival_to, departure_date, departure_time, arrival_time, first_class, business, economy) 
			VALUES(:airbus_no, :flight_no, :depart_from, :arrival_to, :departure_date, :departure_time, :arrival_time, :first_class, :business, :economy)");

		$r->execute(array(
			"airbus_no" => $flight[0],
			"flight_no" => $flight[1],
			"depart_from" => $flight[2],
			"arrival_to" => $flight[3],
			"departure_date" => $flight[4],
			"departure_time" => $flight[5],
			"arrival_time" => $flight[6],
			"first_class" => $flight[7],
			"business" => $flight[8],
			"economy" => $flight[9]
		));
	}

	function deleteFlight($id){
		$db = $GLOBALS['dbConnect'];
		$r = $db->exec("DELETE FROM flight WHERE id_flight =".$id);
	}

	function updateFlight(array $flight)
	{
		$db = $GLOBALS['dbConnect'];
		$r = $db->prepare("UPDATE flight SET airbus_no = :airbus_no, flight_no = :flight_no, depart_from = :depart_from, arrival_to = :arrival_to, departure_date = :departure_date, departure_time = :departure_time, arrival_time = :arrival_time, first_class = :first_class, business = :business, economy = :economy WHERE id_flight = :id_flight");

		$r->execute(array(
			"airbus_no" => $flight[0],
			"flight_no" => $flight[1],
			"depart_from" => $flight[2],
			"arrival_to" => $flight[3],
			"departure_date" => $flight[4],
			"departure_time" => $flight[5],
			"arrival_time" => $flight[6],
			"first_class" => $flight[7],
			"business" => $flight[8],
			"economy" => $flight[9],
			"id_flight" => $flight[10]
		));
	}

	function addAirBus($airBus_no, $capacity){
		$db = $GLOBALS['dbConnect'];
		$r = $db->prepare("INSERT INTO air_bus(airBus_no, capacity) VALUES(:airBus_no, :capacity)");
		$r->execute(array(
			"airBus_no" => $airBus_no,
			"capacity" => $capacity
		));
	}

	function deleteAirBus($id)
	{
		$db = $GLOBALS['dbConnect'];
		$r = $db->exec("DELETE FROM air_bus WHERE id_airBus = ".$id);
	}

	function updateAirBus($id_airBus, $airBus_no, $capacity){
		$db = $GLOBALS['dbConnect'];
		$r = $db->prepare("UPDATE air_bus SET airBus_no = :airBus_no, capacity = :capacity WHERE id_airBus = :id_airBus");
		$r->execute(array(
			"airBus_no" => $airBus_no,
			"capacity" => $capacity,
			"id_airBus" => $id_airBus
		));
	}

	function addUser($email_user, $username, $password_user){
		$db = $GLOBALS['dbConnect'];
		$r = $db->prepare("INSERT INTO user(email_user, username, password_user) 
			VALUES(:email_user, :username, :password_user)");

		$r->execute(array(
			"email_user" => $email_user,
			"username" => $username,
			"password_user" => $password_user
		));
	}

	function deleteUser($id){
		$db = $GLOBALS['dbConnect'];
		$r = $db->exec("DELETE FROM user WHERE id_user = ".$id);
	}

	function updateUser($id_user, $email_user, $username, $password_user){
		$db = $GLOBALS['dbConnect'];
		$r = $db->prepare("UPDATE user SET email_user = :email_user, username = :username, password_user = :password_user WHERE id_user = :id_user");

		$r->execute(array(
			"email_user" => $email_user,
			"username" => $username,
			"password_user" => $password_user,
			"id_user" => $id_user
		));
	}

?>
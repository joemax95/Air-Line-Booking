<?php

	include "Manager.php";
	include 'db_connect.php';

	if (isset($_POST['addFlight'])) {
		addFlight(array(
			$_POST['airBusNo'],
			$_POST['flightNo'],
			$_POST['origine'],
			$_POST['destination'],
			$_POST['departDate'],
			$_POST['departTime'],
			$_POST['arrivalTime'],
			$_POST['first_class'],
			$_POST['business'],
			$_POST['economy']
		));

		header("location: manageflights.php");
	}else if(isset($_POST['editFlight'])){

		updateFlight(array(
			$_POST['airBusNo'],
			$_POST['flightNo'],
			$_POST['origine'],
			$_POST['destination'],
			$_POST['departDate'],
			$_POST['departTime'],
			$_POST['arrivalTime'],
			$_POST['first_class'],
			$_POST['business'],
			$_POST['economy'],
			$_GET['getflight']
		));

		header("location: manageflights.php");

	}else if (isset($_POST['addAirBus'])) {
		addAirBus($_POST['airBusNo'], $_POST['capacity']);

		header("location: newAirbus.php");
	}else if (isset($_POST['editAir'])) {
			
		updateAirBus($_GET['getAirBus'], $_POST['airBusNo'], $_POST['capacity']);
		
		header("location: newAirbus.php");

	}else if (isset($_POST['addUser'])) {

		$r = $db_connect->query("SELECT email_user, username FROM user");

		$row = $r->fetch();

		if ($row['username'] == $_POST['username']) {
			echo "This username is allready exist";
		}else{
			addUser($_POST['email'], $_POST['username'], sha1($_POST['password']));

			header("location: manageAccounts.php");
		}
		
	}else if(isset($_POST['updateUser'])){
		updateUser($_GET['idUser'], $_POST['email'], $_POST['username'], sha1($_POST['password']));
		header("location: manageAccounts.php");
	}

//------------------------------------------------------------------------------

	if (isset($_GET['idDelete'])) {
		deleteUser($_GET['idDelete']);
		header("location: manageAccounts.php");
	}else if (isset($_GET['idUpdate'])) {
		session_start();

		$r = $db_connect->query("SELECT email_user, username, password_user FROM user WHERE id_user =".$_GET['idUpdate']);

		$row = $r->fetch();

		$_SESSION['id_user'] = $_GET['idUpdate'];
		$_SESSION['email_user'] = $row['email_user'];
		$_SESSION['username'] = $row['username'];
		$_SESSION['password_user'] = $row['password_user'];

		header("location: accounts.php");


	}else if(isset($_GET['deleteFlight'])) {
		deleteFlight($_GET['deleteFlight']);
		header("location: manageflights.php");
	}else if (isset($_GET['editFlight'])) {
		session_start();

		$r = $db_connect->query("SELECT airbus_no, flight_no, depart_from, arrival_to, departure_date, departure_time, arrival_time, first_class, business, economy FROM flight WHERE id_flight = ".$_GET['editFlight']);

		$row = $r->fetch();

		$_SESSION['id_flight'] = $_GET['editFlight'];
		$_SESSION['airBusNo'] = $row['airbus_no'];
		$_SESSION['flightNo'] = $row['flight_no'];
		$_SESSION['origine'] = $row['depart_from'];
		$_SESSION['destination'] = $row['arrival_to'];
		$_SESSION['departDate'] = $row['departure_date'];
		$_SESSION['departTime'] = $row['departure_time'];
		$_SESSION['arrivalTime'] = $row['arrival_time'];
		$_SESSION['first_class'] = $row['first_class'];
		$_SESSION['business'] = $row['business'];
		$_SESSION['economy'] = $row['economy'];

		header("location: newflight.php");
	}else if(isset($_GET['deleteAir'])){
		deleteAirBus($_GET['deleteAir']);

		header("location: manageAirbus.php");
	}else if(isset($_GET['updateAir'])){
		session_start();

		$r = $db_connect->query("SELECT airBus_no, capacity FROM air_bus WHERE id_airBus = ".$_GET['updateAir']);

		$row = $r->fetch();

		$_SESSION['id_airBus'] = $_GET['updateAir'];
		$_SESSION['airBus_no'] = $row['airBus_no'];
		$_SESSION['capacity'] = $row['capacity'];

		header("location: newAirbus.php");
	}

?>
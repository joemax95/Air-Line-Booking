
<?php

  include "db_connect.php";

  $date = new DateTime();

  session_start();
    

  if(isset($_SESSION['id_flight']))
    $id_flight = $_SESSION['id_flight'];

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../sidebars/sidebars.css">
</head>
<body>
	<!-- <nav class="navbar navbar-light bg-light">
	  <div class="container">
	    <a class="navbar-brand" href="#">Navbar</a>
	  </div>
	</nav>

	<br> -->

  
  <div class="container-fluid">
    <main>
      <!-- Sidebar -->
      <?php include 'sidebars.php';?>
      <!-- End Sidebar -->
      <div class="b-example-divider"></div>

      <div class="container" style="margin-left: 20px;">
        <br>
        <h3>New Flight</h3>
        <hr class="my-3">

       <form action="process.php?<?php if(isset($_SESSION['id_flight'])) echo "getflight=".$_SESSION['id_flight'] ?>" method="post">
        <div class="row">
          <div class="col-md-3">

            <div class="row">
              <div class="col">
                <label for="exampleDataList" class="form-label">Airbus No</label>
                <select class="form-control" name="airBusNo">
                <?php
                $r = $db_connect->query("SELECT airBus_no FROM air_bus");

                while($row = $r->fetch()){

                ?>
                  <option><?php echo $row['airBus_no']; ?></option>

                <?php
                }
                ?>
                </select>
              </div>
            </div>

            <br>

            <div class="row">
              <div class="col">
                <label for="flightNo" class="form-label">Flight No</label>
                <input type="number" name="flightNo" min ="0" class="form-control" required value="<?php if(isset($_SESSION['flightNo'])) echo $_SESSION['flightNo']; ?>">
              </div>
            </div>

          </div>
        </div>

        <br>

        <div class="row">
          <div class="col-md-3">
            <label for="Origin" class="form-label">From</label>
            <input type="text" name="origine" class="form-control" required value="<?php if(isset($_SESSION['origine'])) echo $_SESSION['origine']; ?>">
          </div>
          <div class="col-md-3">
            <label for="Destination" class="form-label">To</label>
            <input type="text" name="destination" class="form-control" value="<?php if(isset($_SESSION['destination'])) echo $_SESSION['destination']; ?>">
          </div>
        </div>

        <br>

        <div class="row">
          <div class="col-md-3">
            <label for="Departure" class="form-label">Departure date</label>
            <input type="date" name="departDate" class="form-control" required min="<?php echo($date->format('Y-m-d')); ?>" value="<?php if(isset($_SESSION['departDate'])) echo $_SESSION['departDate']; ?>">
          </div>
          <div class="col-md-3">
            <label for="TimeDeparture" class="form-label">Departure time</label>
            <input type="time" name="departTime" class="form-control" required value="<?php if(isset($_SESSION['departTime'])) echo $_SESSION['departTime']; ?>">
          </div>
          <div class="col-md-3">
            <label for="TimeArrival" class="form-label">Arrival time</label>
            <input type="time" name="arrivalTime" class="form-control" required value="<?php if(isset($_SESSION['arrivalTime'])) echo $_SESSION['arrivalTime']; ?>">
          </div>
          
        </div>

        <br>

        <div class="row">

          <div class="col-md-3">
            <div class="accordion accordion-flush border" id="accordionFlushExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="flush-headingOne">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                    Economic
                  </button>
                </h2>
                <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                  <div class="accordion-body">
                    <label for="Economic" class="form-label">Price</label>
                    <input type="number" min="0" name="economy" class="form-control" value="<?php if(isset($_SESSION['economy'])) echo $_SESSION['economy']; ?>">
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-3">
            <div class="accordion accordion-flush border" id="accordionFlushExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="flush-headingTwo">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                    Business
                  </button>
                </h2>
                <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                  <div class="accordion-body">
                    <label for="Business" class="form-label">Price</label>
                    <input type="number" min="0" name="business" class="form-control" value="<?php if(isset($_SESSION['business'])) echo $_SESSION['business']; ?>">
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-3">
            <div class="accordion accordion-flush border" id="accordionFlushExample">
              <div class="accordion-item">
                <h2 class="accordion-header" id="flush-headingThree">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                    First 
                  </button>
                </h2>
                <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                  <div class="accordion-body">
                    <label for="Business" class="form-label">Price</label>
                    <input type="number" min="0" name="first_class" class="form-control" value="<?php if(isset($_SESSION['first_class'])) echo $_SESSION['first_class']; ?>">
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>

        <hr>

          <?php
          if (isset($_SESSION['flightNo'])) {
          ?>
          <button type="submit" class="btn btn-primary w-50 d-flex justify-content-center" name="editFlight">Save Change</button>
          <?php
          }else{
          ?>
          <button type="submit" class="btn btn-primary w-50 d-flex justify-content-center" name="addFlight">Add</button>
          <?php
          }
          ?> 
       </form>
        
      </div>

    </main>    
  </div>
  


<script type="text/javascript" src="../sidebars/sidebars.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>	
</body>
</html>

<?php
  
  unset($_SESSION['airBusNo']);
  unset($_SESSION['flightNo']);
  unset($_SESSION['origine']);
  unset($_SESSION['destination']);
  unset($_SESSION['departDate']);
  unset($_SESSION['departTime']);
  unset($_SESSION['arrivalTime']);
  unset($_SESSION['first_class']);
  unset($_SESSION['business']);
  unset($_SESSION['economy']);  

?>
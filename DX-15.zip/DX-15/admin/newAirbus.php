
<?php

	include "db_connect.php";

  session_start();
    
  if(isset($_SESSION['id_airBus']))
    $id_airBus = $_SESSION['id_airBus'];

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>AirBus</title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../sidebars/sidebars.css">
</head>
<body>
	<!-- <nav class="navbar navbar-light bg-light">
	  <div class="container">
	    <a class="navbar-brand" href="#">Navbar</a>
	  </div>
	</nav>

	<br> -->

  
  <div class="container-fluid">
    <main>
      <!-- Sidebar -->
      <?php include 'sidebars.php';?>
      <!-- End Sidebar -->
      <div class="b-example-divider"></div>

      <div class="container" style="margin-left: 20px;">
        <br>
        <h3>New AirBus</h3>
        <hr class="my-3">

        <br>
        <form action="process.php?<?php if(isset($_SESSION['id_airBus'])) echo "getAirBus=".$_SESSION['id_airBus']; ?>" method="post">
        	<div class="row">
	          <div class="col-md-3">
	            <label for="AirBusNo" class="form-label">AirBus No</label>
	            <input type="number" min="0" name="airBusNo" class="form-control" required value="<?php if(isset($_SESSION['airBus_no'])) echo $_SESSION['airBus_no']; ?>">
	          </div>
	          <div class="col-md-3">
	            <label for="Capacity" class="form-label">Capacity</label>
	            <input type="number" name="capacity" min="200" max="400" class="form-control" required value="<?php if(isset($_SESSION['capacity'])) echo $_SESSION['capacity']; ?>">
	          </div>
	        </div>

	        <br>

	        <hr>

	        <?php
          if (isset($_SESSION['id_airBus'])) {
          ?>
          <button type="submit" class="btn btn-primary w-50 d-flex justify-content-center" name="editAir">Save Change</button>
          <?php
          }else{
          ?>
          <button type="submit" class="btn btn-primary w-50 d-flex justify-content-center" name="addAirBus">Add</button>
          <?php
          }
          ?> 
        </form>
        
        
        <br>
        <br>
        <div class="row">
          <h3>Airbus list</h3>
          <hr class="my-3">

          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#AirBus</th>
                <th scope="col">Capacity</th>
              </tr>
            </thead>
            <tbody>
            <?php

            $r = $db_connect->query("SELECT airBus_no, capacity FROM air_bus");

            while($row = $r->fetch()){

            ?>
              <tr>
                <td><?php echo $row['airBus_no']; ?></td>
                <td><?php echo $row['capacity']; ?></td>
              </tr>
            <?php
            }
            ?>
            </tbody>
          </table>
        </div>
      </div>

    </main>    
  </div>
  


<script type="text/javascript" src="../sidebars/sidebars.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>	
</body>
</html>

<?php
  unset($_SESSION['id_airBus']);
  unset($_SESSION['airBus_no']);
  unset($_SESSION['capacity']);

?>
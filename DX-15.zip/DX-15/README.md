# Airline-Management-System-frontend
Airline Management System Using HTML/CSS and Bootstrap for Booking Tickets

***Pages

1) Home page.
2) signIn/signUp.
3) Ticket Booking.
4) Contact-Us Page.
5) Itineary.
6) Admin Module.
7) Manager Module.
8) User Module.
9) Payment page.
10) Add/Delete Airbus.
11) Add/Delete Flights.


**NOTE: Uncompress Images before using to get excellent experience.

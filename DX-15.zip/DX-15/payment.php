
<?php
  
  include "admin/db_connect.php";

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title></title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="form-validation.css">
</head>
<body>
  <nav class="navbar navbar-light bg-light">
    <div class="container">
      <a class="navbar-brand" href="#">DX-FLIGHT</a>
    </div>
  </nav>

  <br>

<div class="container">
    <main>
      <div class="row g-5">
        <div class="col-md-7 col-lg-8">
          <h4 class="mb-3">Payment Information</h4>
          <hr class="my-4">

          <form class="needs-validation" novalidate action="bookingProcess.php" method="post">
            <div class="row">
              <div class="col-auto">
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" value="paypal">
                  <label class="form-check-label" for="flexRadioDefault1">
                        Paypal
                  </label>
                </div>
              </div>

              <div class="col-auto">
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" value="masterCard" checked>
                  <label class="form-check-label" for="flexRadioDefault2">
                        MasterCard
                  </label>
                </div>
              </div>
            </div>

            <br>

            <div class="row gy-3">
              <div class="col-md-6">
                <label for="CardNumber" class="form-label">Card Number</label>
                <input type="text" class="form-control" placeholder="" required name = "firstname" >
                <div class="invalid-feedback">
                  Please enter Card number
                </div>
              </div>

              <div class="col-md-6">
                <label for="Expiration" class="form-label">Expiration</label>
                <input type="month" class="form-control" placeholder="" required name="lastname">
                <div class="invalid-feedback">
                  Expiration date required
                </div>
              </div>

              <div class="col-md-5">
                <label for="CVC" class="form-label">CVC</label>
                <input type="text" class="form-control" placeholder="" required name="email">
                <div class="invalid-feedback">
                  Security code is required
                </div>
              </div>

            </div>

            <hr class="my-4">

            <button class="w-100 btn btn-primary btn-lg" type="submit" name="pay">Continue payment</button>
          </form>
        </div>
      </div>
    </main>

    <footer class="my-5 pt-5 text-muted text-center text-small">
      <p class="mb-1">&copy; 2021</p>
      <ul class="list-inline">
        <li class="list-inline-item"><a href="#">Privacy</a></li>
        <li class="list-inline-item"><a href="#">Terms</a></li>
        <li class="list-inline-item"><a href="#">Support</a></li>
      </ul>
    </footer>
  </div>
  <script type="text/javascript" src="form-validation.js"></script>  
</body>
</html>
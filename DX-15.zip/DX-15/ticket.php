
<?php

    session_start();


?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ticket</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <style type="text/css">

    @media print{
		body * {
			visibility: hidden;
		}

		.print-container, .print-container * {
			visibility: visible;
		}
	}
    .card{
      margin-left: 15%;
      margin-right: 15%;
      width: auto;
      height: auto;
    }

    .card-header{
      background: #33f;
    }
  </style>
</head>
<body>
  <div class="card border print-container">
    <div class="card-header">
      <h3 class="text-center">Boarding Pass</h3>
    </div>

    <div class="card-body">

      <div class="row">
        <div class="col">
          <div class="row">
            <div class="col">
              <h4>Name of passenger</h4>
            </div>
          </div>
          <div class="row">
            <h4 class="lead"><?php echo $_SESSION['first_name']." ".$_SESSION['last_name'];?></h4>
          </div>
          <br>
          <div class="row">
            <div class="col-auto">
              <h4>From:</h4>
            </div>
            <div class="col-auto">
              <h4 class="lead"><?php echo $_SESSION['from']; ?></h4>
            </div>
          </div>
          <div class="row">
            <div class="col-auto">
              <h4>To:</h4>
            </div>
            <div class="col-auto">
              <h4 class="lead"><?php echo $_SESSION['to']; ?></h4>
            </div>
          </div>
        </div>
  
        <div class="col">
          <div class="row">
            <h4>Boarding Time</h4>
          </div>
          <div class="row">
            <h4 class="lead"><?php echo $_SESSION['departTime']; ?> </h4>
          </div>
        </div>
        <div class="col">
          <div class="row">
            <h4>Depart date</h4>
          </div>
          <div class="row">
            <h4 class="lead"><?php echo $_SESSION['departDate']; ?></h4>
          </div>
        </div>
      </div>
      
      
    </div>
  </div>
  <button onclick="window.print();" class="btn btn-primary">Print</button>
</body>
</html>
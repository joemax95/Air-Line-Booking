<?php

	session_start();

	include 'admin/db_connect.php';

	if (isset($_POST['booking'])) {

		$_SESSION['message'] = "Hello world";
		
		$_SESSION['class'] = $_POST['class'];
		$_SESSION['from'] = $_POST['from'];
		$_SESSION['to'] = $_POST['to'];
		$_SESSION['departDate'] = $_POST['departDate'];
		$_SESSION['returnDate'] = $_POST['returnDate'];
		$_SESSION['adult'] = $_POST['adult'];
		$_SESSION['children'] = $_POST['children'];

		header("location: itineary.php");

	}else if(isset($_GET['setBooking'])){
		$select = $db_connect->query("SELECT depart_from, arrival_to, departure_date, departure_time, arrival_time FROM flight WHERE id_flight = ".$_GET['setBooking']);

		$row = $select->fetch();

		$_SESSION['from'] = $row['depart_from'];
		$_SESSION['to'] = $row['arrival_to'];
		$_SESSION['departDate'] = $row['departure_date'];
		$_SESSION['departTime'] = $row['departure_time'];
		$_SESSION['arrivalTime'] = $row['arrival_time'];

		header("location: booking.php");

	}else if (isset($_POST['passenger'])) {
		
		$r = $db_connect->prepare("INSERT INTO passenger(first_name, last_name, email, phone, birth_date, passport) VALUES(:first_name, :last_name, :email, :phone, :birth_date, :passport)");

		$r->execute(array(
			"first_name" => $_POST['firstname'],
			"last_name" => $_POST['lastname'],
			"email" => $_POST['email'],
			"phone" => $_POST['phone'],
			"birth_date" => $_POST['birth_date'],
			"passport" => $_POST['passport']
		));

		$r = $db_connect->query("SELECT first_name, last_name FROM passenger ORDER BY id_passenger DESC LIMIT 0,1");

		$row = $r->fetch();

		$_SESSION['first_name'] = $row['first_name'];
		$_SESSION['last_name'] = $row['last_name'];

		header("location: payment.php");
	}else if(isset($_POST['pay'])){
		header("location: ticket.php");
	}

?>